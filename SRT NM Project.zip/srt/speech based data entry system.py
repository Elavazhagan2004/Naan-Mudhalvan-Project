import speech_recognition as sr
import pyttsx3
import pandas as pd

# Initialize recognizer and text-to-speech engine
recognizer = sr.Recognizer()
tts_engine = pyttsx3.init()

# Function to speak text
def speak(text):
    tts_engine.say(text)
    tts_engine.runAndWait()

# Function to capture speech input
def listen():
    with sr.Microphone() as source:
        print("Listening...")
        audio = recognizer.listen(source)
        try:
            command = recognizer.recognize_google(audio)
            print(f"You said: {command}")
            return command
        except sr.UnknownValueError:
            speak("Sorry, I didn't catch that.")
            return None
        except sr.RequestError:
            speak("Speech service is down.")
            return None

# Data entry logic
def speech_data_entry():
    data = []
    fields = ["Name", "Age", "Email"]
    
    speak("Let's start data entry. Say 'stop' to finish.")
    
    while True:
        entry = {}
        for field in fields:
            speak(f"Please say the {field}")
            response = listen()
            if response and response.lower() == "stop":
                speak("Stopping data entry.")
                return pd.DataFrame(data)
            elif response:
                entry[field] = response
            else:
                entry[field] = "N/A"
        data.append(entry)
        speak("Entry saved. Say next to continue or stop to finish.")
        next_cmd = listen()
        if next_cmd and next_cmd.lower() == "stop":
            break

    return pd.DataFrame(data)

# Run the system
if __name__ == "__main__":
    df = speech_data_entry()
    print("\nFinal Collected Data:")
    print(df)
    df.to_csv("speech_data_entry.csv", index=False)
    speak("Data has been saved.")
